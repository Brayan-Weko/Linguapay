"use strict";
(() => {
  // src/content/audio-player.ts
  var AUDIO_CROSSFADE_SEC = 0.025;
  var AudioPlayer = class {
    ctx = null;
    bufferCache = /* @__PURE__ */ new Map();
    currentSources = [];
    active = false;
    getAudioContext() {
      if (!this.ctx || this.ctx.state === "closed") {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        this.ctx = new AudioCtx();
      }
      if (this.ctx.state === "suspended") {
        void this.ctx.resume();
      }
      return this.ctx;
    }
    stop() {
      this.active = false;
      for (const src of this.currentSources) {
        try {
          src.stop();
          src.disconnect();
        } catch {
        }
      }
      this.currentSources = [];
    }
    isPlaying() {
      return this.active;
    }
    async fetchBuffer(url) {
      const ctx = this.getAudioContext();
      if (this.bufferCache.has(url)) {
        return this.bufferCache.get(url);
      }
      try {
        const fullUrl = url.startsWith("http") ? url : `http://localhost:8000${url}`;
        const res = await fetch(fullUrl);
        if (!res.ok) return null;
        const arrayBuf = await res.arrayBuffer();
        const audioBuf = await ctx.decodeAudioData(arrayBuf);
        this.bufferCache.set(url, audioBuf);
        return audioBuf;
      } catch {
        return null;
      }
    }
    async playSequence(items) {
      this.stop();
      if (!items || items.length === 0) return;
      this.active = true;
      const ctx = this.getAudioContext();
      const buffers = await Promise.all(items.map((it) => this.fetchBuffer(it.audio_url)));
      if (!this.active) return;
      let startTime = ctx.currentTime + 0.05;
      for (const buf of buffers) {
        if (!buf || !this.active) continue;
        const source = ctx.createBufferSource();
        source.buffer = buf;
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(1, startTime);
        const endTime = startTime + buf.duration;
        gain.gain.setValueAtTime(1, Math.max(startTime, endTime - AUDIO_CROSSFADE_SEC));
        gain.gain.linearRampToValueAtTime(0.01, endTime);
        source.connect(gain);
        gain.connect(ctx.destination);
        source.start(startTime);
        this.currentSources.push(source);
        startTime = Math.max(ctx.currentTime, endTime - AUDIO_CROSSFADE_SEC);
      }
      const totalDurationSec = startTime - ctx.currentTime;
      window.setTimeout(() => {
        if (this.active) {
          this.active = false;
          this.currentSources = [];
        }
      }, Math.max(200, totalDurationSec * 1e3 + 100));
    }
  };

  // src/content/shadow-overlay.ts
  var SHADOW_HOST_ID = "linguapay-shadow-host";
  var ShadowOverlay = class {
    constructor(callbacks) {
      this.callbacks = callbacks;
    }
    host = null;
    shadow = null;
    inspectorOpen = false;
    collapsed = false;
    mount(initialState) {
      if (this.host) return;
      const host = document.createElement("div");
      host.id = SHADOW_HOST_ID;
      host.style.cssText = "all: initial; position: fixed; bottom: 16px; right: 16px; z-index: 2147483647;";
      const shadow = host.attachShadow({ mode: "closed" });
      this.host = host;
      this.shadow = shadow;
      document.documentElement.appendChild(host);
      this.render(initialState);
    }
    render(state2) {
      if (!this.shadow) return;
      const statusColor = state2.apiOnline ? "#34d399" : "#fbbf24";
      const statusText = state2.apiOnline ? "API Connect\xE9e" : "Mode Hors-Ligne (Cache)";
      const inspectorHtml = this.inspectorOpen ? `<div class="inspector-box">
           <div class="section-label">INSPECTEUR D'INT\xC9GRIT\xC9 (JURY)</div>
           ${state2.inspectorEntries.length === 0 ? `<div class="muted">Activez LinguaPay pour inspecter les segments.</div>` : state2.inspectorEntries.slice(0, 6).map(
        (e) => `<div class="insp-row">
                       <span class="badge ${e.integrityPassed ? "ok" : "warn"}">${e.tierUsed}</span>
                       <span class="insp-txt">${this.escapeHtml(e.previewMasked)}</span>
                       <span class="insp-tok">${e.entitiesCount} ent.</span>
                     </div>`
      ).join("")}
         </div>` : "";
      this.shadow.innerHTML = `
      <style>
        .panel {
          font-family: 'Segoe UI', system-ui, sans-serif;
          width: ${this.collapsed ? "190px" : "285px"};
          background: #0f2942;
          color: #f8fafc;
          border: 2px solid #0b6e4f;
          border-radius: 12px;
          box-shadow: 0 14px 32px rgba(15, 23, 42, 0.45);
          overflow: hidden;
          font-size: 12.5px;
        }
        .header {
          background: #0b6e4f;
          padding: 10px 12px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-weight: 700;
        }
        .status-dot {
          width: 9px; height: 9px; border-radius: 50%;
          display: inline-block; background: ${statusColor}; margin-right: 6px;
        }
        .collapse-btn {
          background: rgba(255,255,255,0.18); border: none; color: #fff;
          border-radius: 5px; padding: 2px 7px; cursor: pointer; font-weight: 700;
        }
        .body {
          padding: 12px;
          display: ${this.collapsed ? "none" : "block"};
        }
        .section-label {
          font-size: 10px; font-weight: 700; color: #94a3b8;
          letter-spacing: 0.6px; margin: 8px 0 4px 0;
        }
        select, button.action-btn {
          width: 100%; padding: 7px 9px; border-radius: 6px;
          border: 1px solid #334155; background: #1e293b; color: #f8fafc;
          font-size: 12.5px; font-weight: 600; cursor: pointer;
        }
        button.primary {
          background: ${state2.enabled ? "#dc2626" : "#10b981"};
          border-color: transparent;
          color: #ffffff;
          margin-bottom: 8px;
        }
        button.audio-btn {
          background: #1d4ed8; border-color: transparent; margin-top: 8px;
        }
        label.chk {
          display: flex; align-items: center; gap: 7px; margin: 5px 0;
          cursor: pointer; font-size: 12px;
        }
        .shield-box {
          margin-top: 9px; background: #064e3b; border: 1px solid #10b981;
          border-radius: 6px; padding: 7px 9px; font-size: 11.5px;
        }
        .shield-box strong { color: #6ee7b7; display: block; }
        .inspector-toggle {
          margin-top: 8px; background: transparent; border: 1px dashed #64748b;
          color: #cbd5e1; width: 100%; padding: 5px; border-radius: 5px;
          font-size: 11px; cursor: pointer;
        }
        .inspector-box {
          margin-top: 8px; background: #020617; border-radius: 6px; padding: 8px;
          max-height: 150px; overflow-y: auto;
        }
        .insp-row {
          display: flex; align-items: center; gap: 6px; font-size: 10.5px;
          border-bottom: 1px solid #1e293b; padding: 4px 0;
        }
        .insp-txt { flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: #cbd5e1; }
        .insp-tok { color: #34d399; font-weight: 700; }
        .badge { padding: 1px 4px; border-radius: 3px; font-size: 9.5px; font-weight: 700; }
        .badge.ok { background: #065f46; color: #6ee7b7; }
        .badge.warn { background: #78350f; color: #fde68a; }
        .muted { color: #94a3b8; font-size: 11px; }
      </style>
      <div class="panel">
        <div class="header">
          <span><span class="status-dot"></span>LinguaPay</span>
          <button class="collapse-btn" id="lp-collapse" type="button">${this.collapsed ? "+" : "&minus;"}</button>
        </div>
        <div class="body">
          <div class="muted" style="margin-bottom:6px;">${statusText}</div>
          <button class="action-btn primary" id="lp-toggle" type="button">
            ${state2.enabled ? "Restaurer texte original FR/EN" : "Traduire cette interface"}
          </button>

          <div class="section-label">LANGUE NATIONALE</div>
          <select id="lp-lang">
            <option value="ewondo" ${state2.targetLang === "ewondo" ? "selected" : ""}>Ewondo (Centre / Sud)</option>
            <option value="duala" ${state2.targetLang === "duala" ? "selected" : ""}>Duala (Littoral)</option>
            <option value="fulfulde" ${state2.targetLang === "fulfulde" ? "selected" : ""}>Fulfulde (Grand Nord)</option>
          </select>

          <div class="section-label">ACCESSIBILIT\xC9</div>
          <label class="chk"><input type="checkbox" id="lp-bilingual" ${state2.bilingualMode ? "checked" : ""}/> Mode bilingue (infobulle FR/EN)</label>
          <label class="chk"><input type="checkbox" id="lp-large" ${state2.largeFont ? "checked" : ""}/> Police agrandie (+20%)</label>
          <label class="chk"><input type="checkbox" id="lp-contrast" ${state2.highContrast ? "checked" : ""}/> Fort contraste</label>

          <button class="action-btn audio-btn" id="lp-speak" type="button">&#128266; \xC9couter le r\xE9sum\xE9 (Audio)</button>

          <div class="shield-box">
            <strong>BOUCLIER FINANCIER ACTIF</strong>
            <span>${state2.protectedEntitiesCount} entit\xE9(s) verrouill\xE9e(s) &bull; 0 alt\xE9ration</span>
          </div>

          <button class="inspector-toggle" id="lp-insp-btn" type="button">
            ${this.inspectorOpen ? "Masquer Inspecteur Jury" : "Inspecteur d'Int\xE9grit\xE9 (Jury)"}
          </button>
          ${inspectorHtml}
        </div>
      </div>
    `;
      this.shadow.getElementById("lp-collapse")?.addEventListener("click", () => {
        this.collapsed = !this.collapsed;
        this.render(state2);
      });
      this.shadow.getElementById("lp-toggle")?.addEventListener("click", () => {
        this.callbacks.onToggleEnabled(!state2.enabled);
      });
      this.shadow.getElementById("lp-lang")?.addEventListener("change", (ev) => {
        const val = ev.target.value;
        this.callbacks.onChangeLang(val);
      });
      this.shadow.getElementById("lp-bilingual")?.addEventListener("change", (ev) => {
        this.callbacks.onToggleBilingual(ev.target.checked);
      });
      this.shadow.getElementById("lp-large")?.addEventListener("change", (ev) => {
        this.callbacks.onToggleLargeFont(ev.target.checked);
      });
      this.shadow.getElementById("lp-contrast")?.addEventListener("change", (ev) => {
        this.callbacks.onToggleHighContrast(ev.target.checked);
      });
      this.shadow.getElementById("lp-speak")?.addEventListener("click", () => {
        this.callbacks.onSpeakSummary();
      });
      this.shadow.getElementById("lp-insp-btn")?.addEventListener("click", () => {
        this.inspectorOpen = !this.inspectorOpen;
        this.render(state2);
      });
    }
    escapeHtml(str) {
      return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }
  };

  // src/content/dom-walker.ts
  var EXCLUDED_TAGS = /* @__PURE__ */ new Set([
    "SCRIPT",
    "STYLE",
    "NOSCRIPT",
    "SVG",
    "CODE",
    "PRE",
    "TEXTAREA",
    "INPUT",
    "SELECT",
    "OPTION"
  ]);
  var SENSITIVE_INPUT_KEYWORDS = [
    "pin",
    "cvv",
    "cvc",
    "otp",
    "secret",
    "token",
    "password",
    "passcode"
  ];
  function isSensitiveInput(el) {
    if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement)) {
      return false;
    }
    if (el instanceof HTMLInputElement) {
      const t = (el.type || "").toLowerCase();
      if (t === "password" || t === "hidden") return true;
    }
    const ac = (el.getAttribute("autocomplete") || "").toLowerCase();
    if (ac.startsWith("cc-") || ac === "one-time-code" || ac.includes("password")) {
      return true;
    }
    const fingerprint = `${el.id} ${el.name} ${el.className}`.toLowerCase();
    return SENSITIVE_INPUT_KEYWORDS.some((kw) => fingerprint.includes(kw));
  }
  function isInsideIgnoredSubtree(el) {
    let cur = el;
    while (cur) {
      if (cur.id === SHADOW_HOST_ID || cur.hasAttribute("data-linguapay-ignore")) {
        return true;
      }
      cur = cur.parentElement;
    }
    return false;
  }
  function inferCriticality(el) {
    if (!el) return "UI_NAV";
    const role = (el.getAttribute("role") || "").toLowerCase();
    const cls = (el.className || "").toString().toLowerCase();
    if (role === "alert" || cls.includes("security") || cls.includes("danger") || cls.includes("error")) {
      return "CRITICAL_SECURITY";
    }
    if (cls.includes("balance") || cls.includes("fee") || cls.includes("modal") || cls.includes("dynamic")) {
      return "FINANCIAL_CORE";
    }
    return "UI_NAV";
  }
  var DOMSnapshotManager = class {
    originalTextMap = /* @__PURE__ */ new WeakMap();
    originalPlaceholderMap = /* @__PURE__ */ new WeakMap();
    trackedTextNodes = /* @__PURE__ */ new Set();
    trackedPlaceholders = /* @__PURE__ */ new Set();
    idCounter = 0;
    scan(root = document.body) {
      const segments = [];
      if (!root) return segments;
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode: (node) => {
          const parent = node.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          if (EXCLUDED_TAGS.has(parent.tagName)) return NodeFilter.FILTER_REJECT;
          if (isInsideIgnoredSubtree(parent)) return NodeFilter.FILTER_REJECT;
          if (isSensitiveInput(parent)) return NodeFilter.FILTER_REJECT;
          const val = node.nodeValue ?? "";
          const trimmed = val.trim();
          if (trimmed.length < 2) return NodeFilter.FILTER_REJECT;
          if (parent.getAttribute("data-linguapay-translated") === "1" && this.originalTextMap.has(node)) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      });
      let current;
      while (current = walker.nextNode()) {
        const textNode = current;
        const raw = textNode.nodeValue ?? "";
        const match = raw.match(/^(\s*)([\s\S]*?)(\s*)$/);
        const leadingSpace = match?.[1] ?? "";
        const trimmed = match?.[2] ?? raw.trim();
        const trailingSpace = match?.[3] ?? "";
        if (!trimmed) continue;
        if (!this.originalTextMap.has(textNode)) {
          this.originalTextMap.set(textNode, raw);
        }
        this.trackedTextNodes.add(textNode);
        this.idCounter += 1;
        segments.push({
          id: `dom_${this.idCounter}`,
          kind: "text",
          node: textNode,
          leadingSpace,
          trailingSpace,
          originalTrimmed: this.originalTextMap.get(textNode)?.trim() ?? trimmed,
          criticality: inferCriticality(textNode.parentElement)
        });
      }
      if (root instanceof Element || root === document.body) {
        const container = root;
        const inputs = container.querySelectorAll("input[placeholder], textarea[placeholder]");
        inputs.forEach((el) => {
          if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) || isInsideIgnoredSubtree(el) || isSensitiveInput(el)) {
            return;
          }
          if (el.getAttribute("data-linguapay-ph-translated") === "1" && this.originalPlaceholderMap.has(el)) {
            return;
          }
          const ph = el.placeholder;
          if (!ph || ph.trim().length < 2) return;
          if (!this.originalPlaceholderMap.has(el)) {
            this.originalPlaceholderMap.set(el, ph);
          }
          this.trackedPlaceholders.add(el);
          this.idCounter += 1;
          segments.push({
            id: `ph_${this.idCounter}`,
            kind: "placeholder",
            node: el,
            leadingSpace: "",
            trailingSpace: "",
            originalTrimmed: this.originalPlaceholderMap.get(el) ?? ph,
            criticality: "UI_NAV"
          });
        });
      }
      return segments;
    }
    applyTranslation(seg, translatedText, bilingualTooltip, tierBadge) {
      if (seg.kind === "text" && seg.node instanceof Text) {
        seg.node.nodeValue = `${seg.leadingSpace}${translatedText}${seg.trailingSpace}`;
        const parent = seg.node.parentElement;
        if (parent) {
          parent.setAttribute("data-linguapay-translated", "1");
          parent.setAttribute("data-linguapay-tier", tierBadge);
          if (bilingualTooltip) {
            parent.setAttribute("title", `[Original FR/EN] ${seg.originalTrimmed} (${tierBadge})`);
          } else {
            parent.removeAttribute("title");
          }
        }
      } else if (seg.kind === "placeholder" && (seg.node instanceof HTMLInputElement || seg.node instanceof HTMLTextAreaElement)) {
        seg.node.placeholder = translatedText;
        seg.node.setAttribute("data-linguapay-ph-translated", "1");
      }
    }
    restoreAll() {
      for (const node of this.trackedTextNodes) {
        const orig = this.originalTextMap.get(node);
        if (orig !== void 0 && node.isConnected) {
          node.nodeValue = orig;
        }
        if (node.parentElement) {
          node.parentElement.removeAttribute("data-linguapay-translated");
          node.parentElement.removeAttribute("data-linguapay-tier");
          node.parentElement.removeAttribute("title");
        }
      }
      for (const el of this.trackedPlaceholders) {
        const origPh = this.originalPlaceholderMap.get(el);
        if (origPh !== void 0 && el.isConnected) {
          el.placeholder = origPh;
        }
        el.removeAttribute("data-linguapay-ph-translated");
      }
    }
    clearTracking() {
      this.trackedTextNodes.clear();
      this.trackedPlaceholders.clear();
    }
  };

  // src/content/entity-shield.ts
  var TOKEN_SPLIT_RE = /(\{\{[A-Z]+_\d+\}\})/;
  var TOKEN_FIND_RE = /\{\{[A-Z]+_\d+\}\}/g;
  var REF_RE = /\b(?:TX|REF|ID|OP)-[A-Z0-9-]{4,}\b/g;
  var AMOUNT_RE = /(?:(?<!\w)[+-]\s?)?\b\d{1,3}(?:[\s\u00A0.,]\d{3})*(?:[.,]\d{1,2})?\s?(?:FCFA|F\s?CFA|XAF|CFA|EUR|USD|\$|€)(?=\b|[\s.,;:!?)]|$)/gi;
  var PERCENT_RE = /\b\d+(?:[.,]\d+)?\s?%/g;
  var PHONE_CM_RE = /(?:\+?237[\s.-]?)?6[\d*]{2}(?:[\s.-]?[\d*]{2}){2,3}\b/g;
  var ACCOUNT_RE = /(?:\*{2,4}[\s-]?){1,3}\d{2,4}\b/g;
  var DATE_RE = /\b\d{2}\/\d{2}\/\d{2,4}\b/g;
  var TIME_RE = /\b(?:[01]?\d|2[0-3])[h:][0-5]\d\b/gi;
  var RESIDUAL_NUM_RE = /\b\d+(?:[.,]\d+)?\b/g;
  var BEN_LABEL_RE = /((?:Bénéficiaire|Destinataire|Beneficiary|Recipient)\s*:\s*)([A-ZÀ-Ÿ][A-Za-zÀ-Ÿà-ÿ'’-]+(?:\s+[A-ZÀ-Ÿ][A-Za-zÀ-Ÿà-ÿ'’-]+){0,3})/g;
  var BEN_TRANSFER_RE = /((?:transférer|envoyer|transfer|send)\s+\{\{AMT_\d+\}\}\s+(?:à|to)\s+)([A-ZÀ-Ÿ][A-Za-zÀ-Ÿà-ÿ'’-]+(?:\s+[A-ZÀ-Ÿ][A-Za-zÀ-Ÿà-ÿ'’-]+){0,3})(?=\s*\(|\s*\.|\s*,|$)/gi;
  function replaceOutsideTokens(text, pattern, prefix, entityType, entities, entityTypes, counters) {
    const parts = text.split(TOKEN_SPLIT_RE);
    return parts.map((part) => {
      if (!part) return "";
      if (/^\{\{[A-Z]+_\d+\}\}$/.test(part)) return part;
      return part.replace(pattern, (matched) => {
        const nextIdx = (counters[prefix] ?? 0) + 1;
        counters[prefix] = nextIdx;
        const key = `${prefix}_${nextIdx}`;
        const token = `{{${key}}}`;
        entities[token] = matched;
        entityTypes[key] = entityType;
        return token;
      });
    }).join("");
  }
  var EntityShield = class {
    static lock(text, knownBeneficiaries = []) {
      const entities = {};
      const entityTypes = {};
      const counters = {};
      let masked = text;
      if (knownBeneficiaries.length > 0) {
        const sorted = [...knownBeneficiaries].map((n) => n.trim()).filter(Boolean).sort((a, b) => b.length - a.length);
        for (const name of sorted) {
          const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
          const re = new RegExp(`\\b${escaped}\\b`, "g");
          masked = replaceOutsideTokens(masked, re, "BEN", "BENEFICIARY", entities, entityTypes, counters);
        }
      }
      const orderedRules = [
        [REF_RE, "REF", "REF"],
        [AMOUNT_RE, "AMT", "AMOUNT"],
        [PERCENT_RE, "PCT", "PERCENT"],
        [PHONE_CM_RE, "PHONE", "PHONE_CM"],
        [ACCOUNT_RE, "ACC", "ACCOUNT"],
        [DATE_RE, "DATE", "DATE"],
        [TIME_RE, "TIME", "TIME"]
      ];
      for (const [regex, prefix, etype] of orderedRules) {
        masked = replaceOutsideTokens(masked, regex, prefix, etype, entities, entityTypes, counters);
      }
      for (const benRegex of [BEN_LABEL_RE, BEN_TRANSFER_RE]) {
        masked = masked.replace(benRegex, (full, p1, p2) => {
          if (p2.includes("{{") || p2.includes("}}")) return full;
          const nextIdx = (counters.BEN ?? 0) + 1;
          counters.BEN = nextIdx;
          const key = `BEN_${nextIdx}`;
          const token = `{{${key}}}`;
          entities[token] = p2;
          entityTypes[key] = "BENEFICIARY";
          return `${p1}${token}`;
        });
      }
      masked = replaceOutsideTokens(
        masked,
        RESIDUAL_NUM_RE,
        "NUM",
        "NUMBER",
        entities,
        entityTypes,
        counters
      );
      return { maskedText: masked, entities, entityTypes };
    }
    static unlock(translatedMasked, entities) {
      let out = translatedMasked;
      for (const [token, original] of Object.entries(entities)) {
        out = out.split(token).join(original);
      }
      return out;
    }
    static verifyClientIntegrity(sourceMasked, targetMasked) {
      if (!targetMasked || !targetMasked.trim()) return false;
      const srcTokens = (sourceMasked.match(TOKEN_FIND_RE) ?? []).sort();
      const tgtTokens = (targetMasked.match(TOKEN_FIND_RE) ?? []).sort();
      if (srcTokens.length !== tgtTokens.length) return false;
      for (let i = 0; i < srcTokens.length; i += 1) {
        if (srcTokens[i] !== tgtTokens[i]) return false;
      }
      const outsideDigits = targetMasked.replace(TOKEN_FIND_RE, "");
      return !/\d/.test(outsideDigits);
    }
  };

  // src/content/mutation-watcher.ts
  var OBSERVER_DEBOUNCE_MS = 80;
  var MutationWatcher = class {
    constructor(onMutations) {
      this.onMutations = onMutations;
    }
    observer = null;
    timer = null;
    paused = false;
    pendingRoots = /* @__PURE__ */ new Set();
    start(target = document.body) {
      if (this.observer || !target) return;
      this.observer = new MutationObserver((mutations) => {
        if (this.paused) return;
        let relevant = false;
        for (const m of mutations) {
          if (m.target instanceof Element && m.target.id === SHADOW_HOST_ID) continue;
          if (m.type === "childList" && m.addedNodes.length > 0) {
            m.addedNodes.forEach((n) => {
              if (n instanceof Element && n.id === SHADOW_HOST_ID) return;
              this.pendingRoots.add(n);
              relevant = true;
            });
          } else if (m.type === "characterData" && m.target.parentElement) {
            this.pendingRoots.add(m.target.parentElement);
            relevant = true;
          }
        }
        if (relevant) {
          this.scheduleFlush();
        }
      });
      this.observer.observe(target, {
        childList: true,
        subtree: true,
        characterData: true
      });
    }
    stop() {
      if (this.timer !== null) {
        window.clearTimeout(this.timer);
        this.timer = null;
      }
      this.observer?.disconnect();
      this.observer = null;
      this.pendingRoots.clear();
    }
    runMuted(fn) {
      this.paused = true;
      try {
        fn();
      } finally {
        queueMicrotask(() => {
          this.paused = false;
        });
      }
    }
    scheduleFlush() {
      if (this.timer !== null) {
        window.clearTimeout(this.timer);
      }
      this.timer = window.setTimeout(() => {
        this.timer = null;
        const roots = Array.from(this.pendingRoots);
        this.pendingRoots.clear();
        if (roots.length > 0 && !this.paused) {
          this.onMutations(roots);
        }
      }, OBSERVER_DEBOUNCE_MS);
    }
  };

  // src/content/offline-matcher.ts
  function normalizePhrase(text) {
    return text.trim().toLowerCase().replace(/[\s\u00A0]+/g, " ").replace(/^[\s.:;!?]+|[\s.:;!?]+$/g, "");
  }
  var OfflineMatcher = class {
    packs = /* @__PURE__ */ new Map();
    loadBundle(bundle) {
      const index = /* @__PURE__ */ new Map();
      for (const entry of bundle.entries ?? []) {
        for (const phrase of [...entry.fr ?? [], ...entry.en ?? []]) {
          const norm = normalizePhrase(phrase);
          if (norm && !index.has(norm)) {
            index.set(norm, entry);
          }
        }
      }
      this.packs.set(bundle.language.toLowerCase(), index);
    }
    hasLanguage(lang) {
      return this.packs.has(lang.toLowerCase());
    }
    match(maskedText, lang) {
      const index = this.packs.get(lang.toLowerCase());
      if (!index) return null;
      const norm = normalizePhrase(maskedText);
      const direct = index.get(norm);
      if (direct) {
        return {
          translatedMasked: direct.translation,
          tier: "GLOSSARY_L1",
          criticality: direct.criticality,
          audioClip: direct.audio_clip
        };
      }
      const colon = maskedText.match(/^\s*(.+?)\s*:\s*(\{\{[A-Z]+_\d+\}\})\s*$/);
      if (colon) {
        const hit = index.get(normalizePhrase(colon[1]));
        if (hit) {
          return {
            translatedMasked: `${hit.translation} : ${colon[2]}`,
            tier: "TEMPLATE_L2",
            criticality: hit.criticality,
            audioClip: hit.audio_clip
          };
        }
      }
      return null;
    }
  };

  // src/content/index.ts
  var domManager = new DOMSnapshotManager();
  var offlineMatcher = new OfflineMatcher();
  var audioPlayer = new AudioPlayer();
  var state = {
    enabled: false,
    targetLang: "ewondo",
    bilingualMode: true,
    largeFont: false,
    highContrast: false,
    apiOnline: false,
    protectedEntitiesCount: 0,
    inspectorEntries: []
  };
  var watcher = new MutationWatcher((roots) => {
    if (!state.enabled) return;
    for (const root of roots) {
      if (root.isConnected) {
        void translateRoot(root);
      }
    }
  });
  var overlay = new ShadowOverlay({
    onToggleEnabled: (enabled) => {
      state.enabled = enabled;
      chrome.storage?.local.set({ linguapayEnabled: enabled });
      if (enabled) {
        void activateTranslation();
      } else {
        deactivateTranslation();
      }
    },
    onChangeLang: (lang) => {
      state.targetLang = lang;
      chrome.storage?.local.set({ targetLang: lang });
      if (state.enabled) {
        deactivateTranslation();
        state.enabled = true;
        void activateTranslation();
      } else {
        overlay.render(state);
      }
    },
    onToggleBilingual: (bilingual) => {
      state.bilingualMode = bilingual;
      chrome.storage?.local.set({ bilingualMode: bilingual });
      if (state.enabled) {
        deactivateTranslation();
        state.enabled = true;
        void activateTranslation();
      } else {
        overlay.render(state);
      }
    },
    onToggleLargeFont: (large) => {
      state.largeFont = large;
      applyAccessibilityClasses();
      overlay.render(state);
    },
    onToggleHighContrast: (hc) => {
      state.highContrast = hc;
      applyAccessibilityClasses();
      overlay.render(state);
    },
    onSpeakSummary: () => {
      let summaryText = "";
      const modalSummary = document.getElementById("modal-summary-sentence");
      if (modalSummary && modalSummary.textContent?.trim()) {
        summaryText = modalSummary.textContent.trim();
      } else {
        const balanceEl = document.getElementById("account-balance");
        summaryText = balanceEl ? `Solde disponible : ${balanceEl.textContent?.trim()}` : "Solde disponible : 145 750 FCFA";
      }
      sendBgMessage({
        type: "LINGUAPAY_GET_TTS_SEQUENCE",
        payload: {
          target_lang: state.targetLang,
          text: summaryText
        }
      }).then((resp) => {
        if (resp.ok && resp.data?.items) {
          void audioPlayer.playSequence(resp.data.items);
        }
      });
    }
  });
  function applyAccessibilityClasses() {
    const styleId = "linguapay-a11y-style";
    let styleEl = document.getElementById(styleId);
    if (!state.largeFont && !state.highContrast) {
      styleEl?.remove();
      return;
    }
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = styleId;
      document.head.appendChild(styleEl);
    }
    const rules = [];
    if (state.largeFont) {
      rules.push("body { font-size: 120% !important; }");
    }
    if (state.highContrast) {
      rules.push("[data-linguapay-translated='1'] { text-decoration: underline dotted #0b6e4f; }");
    }
    styleEl.textContent = rules.join("\n");
  }
  function sendBgMessage(msg) {
    return new Promise((resolve) => {
      if (!chrome?.runtime?.sendMessage) {
        resolve({ ok: false, error: "No extension runtime" });
        return;
      }
      chrome.runtime.sendMessage(msg, (resp) => {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message });
        } else {
          resolve(resp ?? { ok: false, error: "Empty response" });
        }
      });
    });
  }
  async function ensureGlossaryLoaded(lang) {
    if (offlineMatcher.hasLanguage(lang)) return;
    const resp = await sendBgMessage({
      type: "LINGUAPAY_GET_GLOSSARY",
      lang
    });
    if (resp.ok && resp.data) {
      offlineMatcher.loadBundle(resp.data);
      state.apiOnline = true;
      chrome.storage?.local.set({ [`glossary_${lang}`]: resp.data });
      return;
    }
    const stored = await chrome.storage?.local.get(`glossary_${lang}`);
    const cachedBundle = stored?.[`glossary_${lang}`];
    if (cachedBundle) {
      offlineMatcher.loadBundle(cachedBundle);
    }
  }
  async function translateRoot(root) {
    const segments = domManager.scan(root);
    if (segments.length === 0) return;
    const shieldedMap = /* @__PURE__ */ new Map();
    const apiItems = [];
    for (const seg of segments) {
      const shielded = EntityShield.lock(seg.originalTrimmed);
      shieldedMap.set(seg.id, { seg, shielded });
      state.protectedEntitiesCount += Object.keys(shielded.entities).length;
      apiItems.push({
        id: seg.id,
        masked_text: shielded.maskedText,
        entity_types: shielded.entityTypes,
        criticality: seg.criticality
      });
    }
    let results = [];
    const apiResp = await sendBgMessage({
      type: "LINGUAPAY_TRANSLATE_BATCH",
      payload: {
        target_lang: state.targetLang,
        source_lang: "auto",
        items: apiItems
      }
    });
    if (apiResp.ok && apiResp.data?.results) {
      state.apiOnline = true;
      results = apiResp.data.results;
    } else {
      state.apiOnline = false;
      results = apiItems.map((it) => {
        const hit = offlineMatcher.match(it.masked_text, state.targetLang);
        if (hit) {
          return {
            id: it.id,
            translated_masked_text: hit.translatedMasked,
            tier_used: `${hit.tier}_OFFLINE`,
            integrity_passed: true,
            fallback_triggered: false
          };
        }
        return {
          id: it.id,
          translated_masked_text: it.masked_text,
          tier_used: "OFFLINE_ORIGINAL",
          integrity_passed: true,
          fallback_triggered: true
        };
      });
    }
    const newEntries = [];
    watcher.runMuted(() => {
      for (const res of results) {
        const pair = shieldedMap.get(res.id);
        if (!pair) continue;
        const { seg, shielded } = pair;
        const clientValid = res.integrity_passed && EntityShield.verifyClientIntegrity(shielded.maskedText, res.translated_masked_text);
        const finalMasked = clientValid ? res.translated_masked_text : shielded.maskedText;
        const finalTier = clientValid ? res.tier_used : "CLIENT_CIRCUIT_BREAKER";
        const restored = EntityShield.unlock(finalMasked, shielded.entities);
        if (!res.fallback_triggered && clientValid && restored !== seg.originalTrimmed) {
          domManager.applyTranslation(seg, restored, state.bilingualMode, finalTier);
        }
        newEntries.push({
          tierUsed: finalTier,
          integrityPassed: clientValid,
          entitiesCount: Object.keys(shielded.entities).length,
          previewMasked: shielded.maskedText
        });
      }
    });
    state.inspectorEntries = [...newEntries.slice(0, 8), ...state.inspectorEntries].slice(0, 12);
    overlay.render(state);
  }
  async function activateTranslation() {
    state.protectedEntitiesCount = 0;
    state.inspectorEntries = [];
    await ensureGlossaryLoaded(state.targetLang);
    await translateRoot(document.body);
    watcher.start(document.body);
    overlay.render(state);
  }
  function deactivateTranslation() {
    watcher.stop();
    watcher.runMuted(() => {
      domManager.restoreAll();
      domManager.clearTracking();
    });
    state.protectedEntitiesCount = 0;
    overlay.render(state);
  }
  async function bootstrap() {
    const health = await sendBgMessage({ type: "LINGUAPAY_HEALTH" });
    state.apiOnline = health.ok;
    const saved = await chrome.storage?.local.get([
      "linguapayEnabled",
      "targetLang",
      "bilingualMode",
      "largeFont",
      "highContrast"
    ]);
    if (saved) {
      state.enabled = Boolean(saved.linguapayEnabled);
      state.targetLang = saved.targetLang || "ewondo";
      state.bilingualMode = saved.bilingualMode !== void 0 ? Boolean(saved.bilingualMode) : true;
      state.largeFont = Boolean(saved.largeFont);
      state.highContrast = Boolean(saved.highContrast);
    }
    overlay.mount(state);
    applyAccessibilityClasses();
    if (state.enabled) {
      await activateTranslation();
    }
    chrome.storage?.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes.targetLang && changes.targetLang.newValue !== state.targetLang) {
        state.targetLang = String(changes.targetLang.newValue);
        if (state.enabled) {
          deactivateTranslation();
          state.enabled = true;
          void activateTranslation();
        } else {
          overlay.render(state);
        }
      }
      if (changes.linguapayEnabled && changes.linguapayEnabled.newValue !== state.enabled) {
        state.enabled = Boolean(changes.linguapayEnabled.newValue);
        if (state.enabled) {
          void activateTranslation();
        } else {
          deactivateTranslation();
        }
      }
    });
  }
  void bootstrap();
})();
